import { Service } from '@angular/core';
import { Injectable,computed, signal, inject} from '@angular/core';
import { IUser, IUsersResponse } from '../interfaces/iuser';
import Swal from 'sweetalert2';
import { HttpClient, httpResource } from '@angular/common/http';

@Service()
export class Users {}

@Injectable({
    providedIn: 'root'
})
export class UsersService {
    private url: string = 'https://peticiones.online/api/users';
    private httpClient = inject(HttpClient);

    misUsuarios = httpResource<IUsersResponse>(() => this.url);
    idUsuario = signal<string | undefined>(undefined);

    getAll() {
        return this.misUsuarios;
    }

    getById(id: number): IUser | undefined {    
        return this.arrayUsers().find(u => u.id == id);
    }

    create(user: IUser): string {
        user.id = this.currentId++;
        this.arrayUsers.update(users => [...users, user]);
        return 'Usuario creado correctamente';
    }

    update(id: number, updatedUser: IUser): string {
        this.arrayUsers.update(users =>
        users.map(u => (u.id == id ? { ...updatedUser, id: u.id } : u))
        );
        return 'Usuario actualizado correctamente';
    }

    delete(id: number): string {
        this.arrayUsers.update(users => users.filter(u => u.id != id));
        return 'Usuario eliminado correctamente';
    }

    deleteConfirmacion(user: IUser, onDeleted?: () => void): void {
        Swal.fire({
        title: '¿Estás seguro?',
        text: `Vas a eliminar a ${user.first_name} ${user.last_name}. Esta acción no se puede deshacer.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
        }).then((result) => {
        if (result.isConfirmed) {
            this.delete(Number(user.id));

            Swal.fire({
            title: '¡Eliminado!',
            text: 'El usuario ha sido eliminado correctamente.',
            icon: 'success',
            confirmButtonColor: '#090909'
            }).then(() => {
            if (onDeleted) onDeleted();
            });
        }
        });
    }

}